package controller;
import model.Fila;
import model.ListaLigada;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class FilaController {

	private ListaLigada Lista = new ListaLigada();
	
	Fila fila = new Fila();
	Runnable runnable = new GeradorSenhaAutomatico(this);
	Thread thread = new Thread(runnable);

	public void novaSenha() {
		System.out.println("\n Incluido Na Fila");
		Lista.adicionarNoFinal(novoElemento);
	}

	public void atender() {
		System.out.println("\n tratar um atendimento da fila...");
	}

	public void gerarSenhaAutomaticamente() {
		System.out.println("\n tratar geracao automatica de senhas...");
		thread.start();
	}
	
	public LocalDateTime getTime() {
		return LocalDateTime.now();
	}
	
	public void calcLeadTimeAtendimento() {
		LocalDateTime time1 = getTime();
		LocalDateTime time2 = getTime().plusDays(2);

		Duration  result = Duration.between(time1, time2);
		
		System.out.println(result.toDays());
	}
}
